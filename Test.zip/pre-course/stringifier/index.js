// Returns a stringified version of input,
// behaving in exactly the same way as JSON.stringify()
function stringifier(input) {}

function parse(input) {}

// Allow tests to run on the server (leave at the bottom)
if (typeof window === "undefined") {
  module.exports = stringifier;
}
